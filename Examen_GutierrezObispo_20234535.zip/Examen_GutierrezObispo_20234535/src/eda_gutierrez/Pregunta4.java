package eda_gutierrez;
// 20234535 Gutierrez Obispo Cesar Gabriel

public class Pregunta4 {
    public static void main(String[] args) {
        char[] lista_entrada = {'a','b','b','c','c','d'};
        char[] caracteres = new char[lista_entrada.length];
        int[] conteo_chars = new int[lista_entrada.length];
        int distintos = 0;

        for (int i = 0; i < lista_entrada.length; i++) {
            char actual = lista_entrada[i];
            int indice = buscarIndice(actual, caracteres, distintos);
            if (indice == -1) {
                caracteres[distintos] = actual;
                conteo_chars[distintos] = 1;
                distintos++;
            } else {
                conteo_chars[indice]++;
            }
        }

        for (int i = 0; i < distintos; i++) {
            System.out.println(caracteres[i] + ": " + conteo_chars[i]);
        }
    }

    public static int buscarIndice(char c, char[] arreglo, int limite) {
        for (int i = 0; i < limite; i++) {
            if (arreglo[i] == c) {
                return i;
            }
        }
        return -1;
    }
}
