package eda_gutierrez;
//20234535 Gutierrez Obispo Cesar Gabriel
public class Pregunta3 {
    public static void main(String[] args) {
        int[] lista={2,3,4,5};
        int suma_pares=0;
        int suma_impares=0;
        int resultado=0;
        for (int i = 0; i <lista.length ; i++) {
            if (lista[i]%2==0) {
                suma_pares+=lista[i];
            }
            else{
                suma_impares+=lista[i];
            }
        }
        System.out.println("Suma de pares: "+suma_pares);
        System.out.println("Suma de impares: "+suma_impares);
        resultado=suma_pares-suma_impares;
        System.out.println("Resultado= "+suma_pares+" + "+suma_impares+" = "+resultado);
    }
}
